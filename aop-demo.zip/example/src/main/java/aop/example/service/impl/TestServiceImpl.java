/**
 * Project Name: example
 * File Name: TestServiceImpl
 * Package Name: aop.example.service.impl
 * Date: 2020/6/2 10:37
 * Author: 方瑞冬
 */
package aop.example.service.impl;

import aop.example.entity.Dog;
import aop.example.entity.User;
import aop.example.service.TestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
@Slf4j
public class TestServiceImpl implements TestService {
    @Override
    public Dog getDogByUser(String id, User user, Date now) {
        log.info("传入的参数为：id={}, userName={}, userAge={}, now={}", id, user.getAge(), user.getAge(), now);
        Dog dog = Dog.builder().nickName("拆家能手").breed("哈士奇").build();
        log.info("狗的信息为：nickName={}, breed={}", dog.getNickName(), dog.getBreed());
        return dog;
    }
}
