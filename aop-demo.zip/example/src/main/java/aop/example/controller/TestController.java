/**
 * Project Name: example
 * File Name: TestController
 * Package Name: aop.example.controller
 * Date: 2020/6/2 10:21
 * Author: 方瑞冬
 */
package aop.example.controller;

import aop.example.annotation.SystemLog;
import aop.example.entity.Dog;
import aop.example.entity.User;
import aop.example.result.Result;
import aop.example.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/aop")
public class TestController {
    @Autowired
    private TestService testService;

    @PostMapping("/test/{id}")
    @SystemLog
    public Result<Dog> aopTest(@PathVariable String id, @RequestBody User user, @RequestParam Date now) {
        Dog dog = testService.getDogByUser(id, user, now);
        return new Result<>(dog);
    }
}
