/**
 * Project Name: example
 * File Name: SystemLogAspect
 * Package Name: aop.example.aop
 * Date: 2020/6/2 10:45
 * Author: 方瑞冬
 */
package aop.example.aop;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
@Slf4j
public class SystemLogAspect {
    @Autowired
    private HttpServletRequest request;

    /**
     * @author: 韭菜馅糖包
     * @date: 2020/6/2 10:49
     * @since: JDK 1.8
     * @description: 定义切面
     * @param: []
     * @return: void
     */
    @Pointcut("@annotation(aop.example.annotation.SystemLog)")
    public void controllerAspect() {
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2020/6/2 10:53
     * @since: JDK 1.8
     * @description: 后置通知
     * @param: [joinPoint, returnValue]
     * @return: void
     */
    @AfterReturning(value = "controllerAspect()", returning = "returnValue")
    public void doAfter(JoinPoint joinPoint, Object returnValue) {
        //RequestParam 参数
        String requestParam = request.getQueryString();
        log.info("AOP 打印 RequestParam 参数:{}", requestParam);

        //PathVariable 参数
        Object pathVariable = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        log.info("AOP 打印 PathVariable 参数:{}", pathVariable);

        //RequestBody 参数
        Object[] requestBody = joinPoint.getArgs();
        String requestBodyJsonStr = JSON.toJSONString(requestBody);
        log.info("AOP 打印 RequestBody 参数:{}", requestBodyJsonStr);

        //返回值
        log.info("AOP 打印 返回值:{}", returnValue);
    }
}
