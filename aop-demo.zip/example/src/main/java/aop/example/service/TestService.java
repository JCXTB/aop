/**
 * Project Name: example
 * File Name: TestService
 * Package Name: aop.example.service
 * Date: 2020/6/2 10:22
 * Author: 方瑞冬
 */
package aop.example.service;

import aop.example.entity.Dog;
import aop.example.entity.User;

import java.util.Date;

public interface TestService {
    Dog getDogByUser(String id, User user, Date now);
}
