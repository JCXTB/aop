/**
 * Project Name: example
 * File Name: Dog
 * Package Name: aop.example.entity
 * Date: 2020/6/2 10:26
 * Author: 方瑞冬
 */
package aop.example.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Dog {
    private String nickName;

    private String breed;
}
