/**
 * Project Name: example
 * File Name: User
 * Package Name: aop.example.entity
 * Date: 2020/6/2 10:19
 * Author: 方瑞冬
 */
package aop.example.entity;

import lombok.Data;

@Data
public class User {
    private String name;

    private Integer age;
}
